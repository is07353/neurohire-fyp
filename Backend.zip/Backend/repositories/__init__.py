from . import candidate_repo
from . import job_repo
from . import cv_repo
from . import application_repo
from . import video_repo

__all__ = ["candidate_repo", "job_repo", "cv_repo", "application_repo", "video_repo"]
